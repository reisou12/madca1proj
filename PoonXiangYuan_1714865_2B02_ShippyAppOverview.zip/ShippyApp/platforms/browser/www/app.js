
// Initialize Firebase


var config = {
    apiKey: "AIzaSyCRj1fPlt2GbxWN2rcISIsrzj85C-FMqeI",
    authDomain: "bpl-test01.firebaseapp.com",
    databaseURL: "https://bpl-test01.firebaseio.com",
    projectId: "bpl-test01",
    storageBucket: "bpl-test01.appspot.com",
    messagingSenderId: "620395282902"
};
firebase.initializeApp(config);

//Get elements
const txtEmail = document.getElementById('txtEmail');
const txtPassword = document.getElementById('txtPassword');
const txtEmailSU = document.getElementById('txtEmailSU');
const txtPasswordSU = document.getElementById('txtPasswordSU');
const txtNameSU = document.getElementById('txtNameSU');
const btnLogin = document.getElementById('btnLogin');
const btnSignUp = document.getElementById('btnSignUp');
const btnLogout = document.getElementById('btnLogout');
const shipmentSubmit = document.getElementById('shipmentSubmit');
const shipmentId = document.getElementById('shipmentId');
const shipmentName = document.getElementById('shipmentName');
const retrieveShipment = document.getElementById('retrieveShipment');
const shipmentsList = document.getElementById('shipmentsList');
const usernamedisplay = document.getElementById('username');

//Authentication persistence


//Add login event
btnLogin.addEventListener('click', e => {
    //Get email and pass
    const email = txtEmail.value;
    const pass = txtPassword.value;
    const auth = firebase.auth();
    // Sign in
    firebase.auth().signInWithEmailAndPassword(email, pass).catch(e => alert(e.message));
    firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE)
        .then(function () {
            // Existing and future Auth states are now persisted in the current
            // session only. Closing the window would clear any existing state even
            // if a user forgets to sign out.
            // ...
            // New sign-in will be persisted with session persistence.
            return firebase.auth().signInWithEmailAndPassword(email, password);

        })
        .catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
        });
});

//Add Sign Up event
btnSignUp.addEventListener('click', e => {
    //Get email and pass
    const email = txtEmailSU.value;
    const pass = txtPasswordSU.value;
    const username = txtNameSU.value;
    const auth = firebase.auth().currentUser;

    // Sign Up
    firebase.auth().createUserWithEmailAndPassword(email, pass).catch(e => alert(e.message))
    setTimeout(function () {
        firebase.auth().onAuthStateChanged(firebaseUser => {
            if (firebaseUser) {
                firebase.database().ref('users/' + firebase.auth().currentUser.uid + "/" + 'profile').set({
                    name: username
                })
            } else {
                console.log('not logged in');
            }
        })
    }, 2000);
    firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE)
        .then(function () {
            // Existing and future Auth states are now persisted in the current
            // session only. Closing the window would clear any existing state even
            // if a user forgets to sign out.
            // ...
            // New sign-in will be persisted with session persistence.
            return firebase.auth().signInWithEmailAndPassword(email, password);

        })
        .catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
        });
});

btnLogout.addEventListener('click', e => {
    firebase.auth().signOut();
})

//add a realtime listener
firebase.auth().onAuthStateChanged(firebaseUser => {
    if (firebaseUser) {
        // console.log(firebaseUser);
        const username = firebase.database().ref('users/' + firebaseUser.uid + "/" + 'profile')
        username.on('value', snap => {
            console.log(snap.val().name);
            var info = JSON.stringify(snap.val().name);
            usernamedisplay.innerText = snap.val().name;
        });

        txtEmail.classList.add('hide');
        txtPassword.classList.add('hide');
        btnLogin.classList.add('hide');
        btnSignUp.classList.add('hide');
        btnLogout.classList.remove('hide');
    } else {
        location.href = "#login";
        console.log('not logged in');
        txtEmail.classList.remove('hide');
        txtPassword.classList.remove('hide');
        btnSignUp.classList.remove('hide');
        btnLogout.classList.add('hide');
        btnLogin.classList.remove('hide');
    }
})

//Get elements
var uploader = document.getElementById('uploader');
var fileButton = document.getElementById('fileButton');

//listen for file selection
fileButton.addEventListener('change', function (e) {
    //Get User
    var user = firebase.auth().currentUser;
    //Get file
    var file = e.target.files[0];
    //create  a storage ref
    var storageRef = firebase.storage().ref('users/' + user.uid + "/" + file.name);
    //Upload file
    var task = storageRef.put(file);
    //update progress bar
    task.on('state_changed',
        function progress(snapshot) {
            var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            uploader.value = percentage;
        },
        function error(err) {

        },
        function complete() {

        }
    );
});

function logintoHome() {
    setTimeout(function () {
        firebase.auth().onAuthStateChanged(firebaseUser => {
            if (firebaseUser) {
                // console.log(firebaseUser);
                location.href = "#home";
            } else {
                console.log('not logged in');
            }
        })
    }, 2000);

}

function clearInputs() {
    shipmentName.value = "";
    shipmentId.value = "";

}

shipmentSubmit.addEventListener('click', function (e) {
    var user = firebase.auth().currentUser;
    var shipmentDetails = { name: shipmentName.value, id: shipmentId.value };
    // console.log(shipmentId.value + " " + shipmentName.value);
    console.log(shipmentDetails);
    var data = shipmentDetails;
    console.log("This is json data: " + data);
    //create database ref
    // var database = firebase.database.ref('users/' + user.uid).child('items').update();
    var ref = firebase.database().ref('users/' + user.uid + "/shipmentDetails")
    var pushedref = ref.push(
        data, function (error) {
            if (error) {
                console.log("Failed to be submitted")
            } else {
                console.log("Successfully submitted" + pushedref.key)
            };
            var s = ref.child('shipments').once('value', function (snapshot) {
                console.log("First log before key" + snapshot.val().key);
                snapshot = snapshot.val().key + pushedref.key + "/";
                console.log(snapshot);
                ref.child('shipments').set({ key: snapshot });
            });
        });
    clearInputs()
});

retrieveShipment.addEventListener('click', function () {
    var userId = firebase.auth().currentUser.uid;
    var ref = firebase.database().ref('users/' + userId + "/shipmentDetails" + "/shipments");
    var s = "";
    var noCheck = ref.on('value', function (snapshot) {
        for (i = 0; i < snapshot.val().key.length; i++) {
            if (snapshot.val().key.charAt(i) !== "/") {
                s += snapshot.val().key.charAt(i);
            }
            
        }
    });


    const dbRefObject = firebase.database().ref('users/' + userId + "/shipmentDetails");
    // const dbRefObject = firebase.database().ref('users/' + userId).orderByChild('name');
    dbRefObject.on('value', snap => {


        var info = JSON.stringify(snap.val(), null, 3);


        shipmentsList.innerText = info;
        // for (i = 0; i < snap.val().length; i++) {
        //     console.log(info)
        //     // Find a <table> element with id="myTable":
        //     var table = document.getElementById('shipmentsTable');
        //     // Create an empty <tr> element and add it to the 1st position of the table:
        //     var row = table.insertRow(0);

        //     // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
        //     var cell1 = row.insertCell(0);
        //     var cell2 = row.insertCell(1);

        //     // Add some text to the new cells:
        //     cell1.innerHTML = info[0];
        //     cell2.innerHTML = inf0[1];
        // }
    });
});

