
// Initialize Firebase
var config = {
    apiKey: "AIzaSyDlKGzLmwCHAJKr4mOvV7G9FRB2JuQokzE",
    authDomain: "mad2ca1-c3966.firebaseapp.com",
    databaseURL: "https://mad2ca1-c3966.firebaseio.com",
    projectId: "mad2ca1-c3966",
    storageBucket: "mad2ca1-c3966.appspot.com",
    messagingSenderId: "921634051897"
};
firebase.initializeApp(config);

//Get elements
const txtEmail = document.getElementById('txtEmail');
const txtPassword = document.getElementById('txtPassword');
const txtEmailSU = document.getElementById('txtEmailSU');
const txtPasswordSU = document.getElementById('txtPasswordSU');
const txtNameSU = document.getElementById('txtNameSU');
const btnLogin = document.getElementById('btnLogin');
const btnSignUp = document.getElementById('btnSignUp');
const btnLogout = document.getElementById('btnLogout');
const shipmentSubmit = document.getElementById('shipmentSubmit');
const shipmentId = document.getElementById('shipmentId');
const shipmentName = document.getElementById('shipmentName');
const retrieveShipment = document.getElementById('retrieveShipment');
const shipmentsList = document.getElementById('shipmentsList');
const usernamedisplay = document.getElementById('username');
var arr = [];
var userId = "";
var chosenIndex = 0;

function convertAddress(address) {

    $.getJSON("https://maps.googleapis.com/maps/api/geocode/json?", { address: address, key: "AIzaSyDE6HxuilTAHLb1_3AEtmamgELGscJYcsE" }, function (json) {
        console.log('getjson callback triggered');
        console.log(JSON.stringify(json));
        var lat = json.results[0].geometry.location.lat;
        var lng = json.results[0].geometry.location.lng;
        console.log('location found at: ' + 'lat: ' + lat + ' lng: ' + lng);
        var pos = { lat: lat, lng: lng };
        firebase.database().ref('users/' + firebase.auth().currentUser.uid + "/" + 'profile' + "/" + 'address').set({
            address: pos
        });
        centerTheMap(map, pos);
    }
    )
}

function centerTheMap(map, pos) {
    var map = new google.maps.Map(document.getElementById('map-canvas'), {
        center: { lat: 1.3083, lng: 103.7776 },
        zoom: 18
    });
    map.setCenter(pos);
    console.log("centering")
}

function getLocation(map) {
    //checks if the browser supports geolocation  
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            // console.log('geolocation success');
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            // console.log('lat:' + lat + 'lng:' + lng);
            //center the map
            var pos = { lat: lat, lng: lng };
            map.setCenter(pos);
            var info = new google.maps.InfoWindow();
            info.setPosition(pos);
            info.setContent('Location is:' + pos.lat + ' ' + pos.lng);
            info.open(map);
        }, function () {
            alert('no location found')
        });
    }
}

function queryData() {
    var rootRef = firebase.database().ref();
    var shipmentDetailsRef = rootRef.child("users/" + userId + "/shipmentDetails/");
    // order by key is for sorting, sorts by the key
    var query = shipmentDetailsRef.orderByKey().limitToLast(100);
    //loop through the query
    var s = "";
    query.on("child_added", function (snapshot) {
        var id = snapshot.val().id;
        var name = snapshot.val().name;
        console.log(id + ' ' + name);
        //create new object
        arr.push(snapshot.key);
        console.log("key is " + snapshot.key);

        s = s + "<li><a href='#'>" + id + " " + name + " " + "</a></li>";
        $('#shipmentsList').html(s);
        $('#shipmentsList').listview('refresh');
    })
}

//page create/show functions
$(document).on("pageshow", "#trigger", function () {
    queryData();
    $('#shipmentsList').on('tap', 'li', function () {
        console.log('You tapped index: ' + $(this).index());
        //store index into the global variable
        chosenIndex = $(this).index();
        //navigate to the next page programmatically
        $(":mobile-pagecontainer").pagecontainer("change", "#triggermenu", { role: "page" });
    })
})

$(document).on('pageshow', '#triggermenu', function () {
    var currentAddress = firebase.database().ref('users/' + firebase.auth().currentUser.uid + "/" + 'profile' + "/" + 'address')
    currentAddress.on('value', snap => {
        if (snap.val().address != null) {
            var pos = snap.val().address;
            console.log(pos);
            centerTheMap(map, pos);
        } else { }
    })
    console.log('triggermenu create');
    var map = new google.maps.Map(document.getElementById('map-canvas'), {
        center: { lat: 1.3083, lng: 103.7776 },
        zoom: 18
    });

    $('#id').html("Shipment Id:" + arr[chosenIndex]);
    // $('#name').html(arr[chosenIndex].name);
    //change the attribute of the img element
    // $('#img').attr("src", "im2/" + arr[chosenIndex].imgbig);

    $('#addressSubmit').on('tap', function () {
        var address = $('#deliveryAddress').val();
        convertAddress(address);
    })

})

//Add login event
btnLogin.addEventListener('click', function () {
    //Get email and pass
    const email = txtEmail.value;
    const pass = txtPassword.value;
    // Sign in
    firebase.auth().signInWithEmailAndPassword(email, pass).catch(e => alert(e.message));
    firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE)
        .then(function () {
            // Existing and future Auth states are now persisted in the current
            // session only. Closing the window would clear any existing state even
            // if a user forgets to sign out.
            // ...
            // New sign-in will be persisted with session persistence.
            return firebase.auth().signInWithEmailAndPassword(email, password);

        })
        .catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorCode + errorMessage);
        });
});

//Add Sign Up event
btnSignUp.addEventListener('click', function () {
    //Get email and pass
    const email = txtEmailSU.value;
    const pass = txtPasswordSU.value;
    const username = txtNameSU.value;

    // Sign Up
    firebase.auth().createUserWithEmailAndPassword(email, pass).catch(e => alert(e.message))
    setTimeout(function () {
        firebase.auth().onAuthStateChanged(firebaseUser => {
            if (firebaseUser) {
                firebase.database().ref('users/' + firebase.auth().currentUser.uid + "/" + 'profile' + "/" + "name").set({
                    name: username
                })
            } else {
                console.log('not logged in');
            }
        })
    }, 2000);
    firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE)
        .then(function () {
            // Existing and future Auth states are now persisted in the current
            // session only. Closing the window would clear any existing state even
            // if a user forgets to sign out.
            // ...
            // New sign-in will be persisted with session persistence.
            return firebase.auth().signInWithEmailAndPassword(email, password);

        })
        .catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorCode + errorMessage);
        });
});

btnLogout.addEventListener('click', function () {
    firebase.auth().signOut();
})

//add a realtime listener
firebase.auth().onAuthStateChanged(firebaseUser => {
    if (firebaseUser) {
        // console.log(firebaseUser);
        const username = firebase.database().ref('users/' + firebaseUser.uid + "/" + 'profile' + "/" + 'name')
        username.on('value', snap => {
            console.log(snap.val().name);
            var info = JSON.stringify(snap.val().name);
            console.log("strigify info" + info);
            usernamedisplay.innerText = snap.val().name;
            userId = firebaseUser.uid;
            return userId
        });

        txtEmail.classList.add('hide');
        txtPassword.classList.add('hide');
        btnLogin.classList.add('hide');
        btnSignUp.classList.add('hide');
        btnLogout.classList.remove('hide');
    } else {
        location.href = "#login";
        console.log('not logged in');
        txtEmail.classList.remove('hide');
        txtPassword.classList.remove('hide');
        btnSignUp.classList.remove('hide');
        btnLogout.classList.add('hide');
        btnLogin.classList.remove('hide');
    }
})

//Get elements
var uploader = document.getElementById('uploader');
var fileButton = document.getElementById('fileButton');

//listen for file selection
fileButton.addEventListener('change', function (e) {
    //Get User
    var user = firebase.auth().currentUser;
    //Get file
    var file = e.target.files[0];
    //create  a storage ref
    var storageRef = firebase.storage().ref('users/' + user.uid + "/" + file.name);
    //Upload file
    var task = storageRef.put(file);
    //update progress bar
    task.on('state_changed',
        function progress(snapshot) {
            var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            uploader.value = percentage;
        },
        function error(err) {
            console.log(err);

        },
        function complete() {

        }
    );
});

function logintoHome() {
    setTimeout(function () {
        firebase.auth().onAuthStateChanged(firebaseUser => {
            if (firebaseUser) {
                // console.log(firebaseUser);
                location.href = "#home";
            } else {
                console.log('not logged in');
            }
        })
    }, 2000);

}

function clearInputs() {
    shipmentName.value = "";
    shipmentId.value = "";

}

shipmentSubmit.addEventListener('click', function () {
    var user = firebase.auth().currentUser;
    var shipmentDetails = { name: shipmentName.value, id: shipmentId.value };
    // console.log(shipmentId.value + " " + shipmentName.value);
    console.log(shipmentDetails);
    var data = shipmentDetails;
    console.log("This is json data: " + data);
    //create database ref
    // var database = firebase.database.ref('users/' + user.uid).child('items').update();
    var ref = firebase.database().ref('users/' + user.uid + "/shipmentDetails")
    var pushedref = ref.push(
        data, function (error) {
            if (error) {
                console.log("Failed to be submitted")
            } else {
                console.log("Successfully submitted" + pushedref.key)
            };
        });
    clearInputs()
});
